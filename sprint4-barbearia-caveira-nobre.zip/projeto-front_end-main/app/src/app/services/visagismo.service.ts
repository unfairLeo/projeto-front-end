import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
// Adicionando opções aos rostos novos criados: triangular e quadrado
// E aos cabelos acrescentaos: crespo e ondulados
export class VisagismoService {
  recomendar(rosto: string, cabelo: string): string[] {
    const chave = `${rosto}-${cabelo}`;
    const mapa: Record<string, string[]> = {
      'Oval-Liso': ['Side Part clássico', 'Pompadour baixo'],
      'Oval-Cacheado': ['Crop texturizado', 'Top cacheado com degradê'],
      'Redondo-Liso': ['Undercut com volume no topo', 'Quiff médio'],
      'Redondo-Cacheado': ['Degradê alto com topo cacheado', 'Curly crop'],
      'Quadrado-Liso': ['Buzz cut com barba marcada', 'Crew cut'],
      'Quadrado-Cacheado': ['Fade com topo natural', 'Corte médio com textura'],
      'Triangular-Liso':['Topete ou Volume Superior','Franja assimétrica ou repicada'],
      'Triangular-Cacheado':['Shaggy Hair Cacheado','Pixie Cut Cacheado'],
      'Triangular-Crespo':['Taper Fade com Volume no Topo','Black Power'],
      'Triangular-Ondulado':['Long Bob em Camadas','Wolf Cut'],
      'Oval-Crespo':['Low Fade ou Mid Fade Afro','Corte Esponjado'],
      'Oval-Ondulado':['Long Bob','Corte em Camadas'],
      'Quadrado-Crespo':['Corte Redondo / Flat Top arredondado','Esponjado / Sponge Twists'],
      'Quadrado-Ondulado':['Croped Texturizado','Social Esporte Fino'],
    };

    return mapa[chave] ?? ['Degradê clássico', 'Corte social com acabamento na navalha'];
  }
}
