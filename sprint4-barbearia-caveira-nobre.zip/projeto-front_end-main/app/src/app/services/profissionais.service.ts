import { Injectable } from '@angular/core';
import { Profissional, ProfissionalFormData } from '../models/profissional.model';

@Injectable({ providedIn: 'root' })
export class ProfissionaisService {
  private readonly STORAGE_KEY = 'barbearia_profissionais';

  private profissionais: Profissional[] = [
    { id: 1, nome: 'Barbeiro Carlos', especialidade: 'Corte e Barba', telefone: '(11) 91234-5678', ativo: true },
    { id: 2, nome: 'Barbeiro Marco', especialidade: 'Tratamentos Capilares', telefone: '(11) 92345-6789', ativo: true }
  ];

  private proximoId = 3;

  constructor() {
    this.carregarDoLocalStorage();
  }

  private carregarDoLocalStorage(): void {
    try {
      const dados = localStorage.getItem(this.STORAGE_KEY);
      if (dados) {
        const parsed = JSON.parse(dados);
        if (parsed.profissionais) this.profissionais = parsed.profissionais;
        if (parsed.proximoId) this.proximoId = parsed.proximoId;
      }
    } catch (e) { console.error('Erro ao carregar profissionais:', e); }
  }

  private salvarNoLocalStorage(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify({ profissionais: this.profissionais, proximoId: this.proximoId }));
    } catch (e) { console.error('Erro ao salvar profissionais:', e); }
  }

  listar(): Profissional[] { return [...this.profissionais]; }

  adicionar(dados: ProfissionalFormData): Profissional {
    const novo: Profissional = { id: this.proximoId++, ...dados };
    this.profissionais = [novo, ...this.profissionais];
    this.salvarNoLocalStorage();
    return novo;
  }

  atualizar(id: number, dados: ProfissionalFormData): Profissional | null {
    const idx = this.profissionais.findIndex(p => p.id === id);
    if (idx === -1) return null;
    const atualizado: Profissional = { id, ...dados };
    this.profissionais[idx] = atualizado;
    this.salvarNoLocalStorage();
    return atualizado;
  }

  excluir(id: number): void {
    this.profissionais = this.profissionais.filter(p => p.id !== id);
    this.salvarNoLocalStorage();
  }
}
