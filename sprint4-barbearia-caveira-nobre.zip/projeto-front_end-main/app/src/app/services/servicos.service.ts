import { Injectable } from '@angular/core';
import { Servico, ServicoFormData } from '../models/servico.model';

@Injectable({
  providedIn: 'root'
})
export class ServicosService {
  private readonly STORAGE_KEY = 'barbearia_servicos';

  private servicos: Servico[] = [
    { id: 1, nome: 'Corte tradicional', descricao: 'Acabamento clássico na tesoura e máquina.', preco: 50, popularidade: 5, categoria: 'Corte' },
    { id: 2, nome: 'Barba premium', descricao: 'Modelagem completa com toalha quente.', preco: 40, popularidade: 4, categoria: 'Barba' },
    { id: 3, nome: 'Combo Caveira', descricao: 'Corte + barba + finalização.', preco: 80, popularidade: 5, categoria: 'Combo' },
    { id: 4, nome: 'Hidratação capilar', descricao: 'Tratamento para brilho e fortalecimento.', preco: 60, popularidade: 3, categoria: 'Tratamento' }
  ];

  private proximoId = 5;

  constructor() {
    this.carregarDoLocalStorage();
  }

  private carregarDoLocalStorage(): void {
    try {
      const dadosSalvos = localStorage.getItem(this.STORAGE_KEY);

      if (!dadosSalvos) {
        return;
      }

      const dados = JSON.parse(dadosSalvos);

      if (dados.servicos && Array.isArray(dados.servicos)) {
        this.servicos = dados.servicos;
      }

      if (typeof dados.proximoId === 'number') {
        this.proximoId = dados.proximoId;
      }
    } catch (erro) {
      console.error('Erro ao carregar serviços do localStorage:', erro);
    }
  }

  private salvarNoLocalStorage(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify({
        servicos: this.servicos,
        proximoId: this.proximoId
      }));
    } catch (erro) {
      console.error('Erro ao salvar serviços no localStorage:', erro);
    }
  }

  listar(): Servico[] {
    return [...this.servicos].sort((a, b) => b.popularidade - a.popularidade);
  }

  adicionar(dados: ServicoFormData): Servico {
    const novoServico: Servico = {
      id: this.proximoId++,
      ...dados
    };

    this.servicos = [novoServico, ...this.servicos];
    this.salvarNoLocalStorage();

    return novoServico;
  }

  atualizar(id: number, dados: ServicoFormData): Servico | null {
    const indice = this.servicos.findIndex((servico) => servico.id === id);

    if (indice === -1) {
      return null;
    }

    const atualizado: Servico = {
      id,
      ...dados
    };

    this.servicos[indice] = atualizado;
    this.salvarNoLocalStorage();

    return atualizado;
  }

  excluir(id: number): void {
    this.servicos = this.servicos.filter((servico) => servico.id !== id);
    this.salvarNoLocalStorage();
  }
}
