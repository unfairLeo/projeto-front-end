import { Injectable } from '@angular/core';
import { Cliente, ClienteFormData } from '../models/cliente.model';

@Injectable({ providedIn: 'root' })
export class ClientesService {
  private readonly STORAGE_KEY = 'barbearia_clientes';

  private clientes: Cliente[] = [
    { id: 1, nome: 'João Silva', telefone: '(11) 98765-4321', email: 'joao@email.com', dataCadastro: '2026-01-10' },
    { id: 2, nome: 'Pedro Santos', telefone: '(11) 99876-5432', email: 'pedro@email.com', dataCadastro: '2026-02-14' },
    { id: 3, nome: 'Lucas Oliveira', telefone: '(11) 97654-3210', email: 'lucas@email.com', dataCadastro: '2026-03-05' }
  ];

  private proximoId = 4;

  constructor() {
    this.carregarDoLocalStorage();
  }

  private carregarDoLocalStorage(): void {
    try {
      const dados = localStorage.getItem(this.STORAGE_KEY);
      if (dados) {
        const parsed = JSON.parse(dados);
        if (parsed.clientes) this.clientes = parsed.clientes;
        if (parsed.proximoId) this.proximoId = parsed.proximoId;
      }
    } catch (e) { console.error('Erro ao carregar clientes:', e); }
  }

  private salvarNoLocalStorage(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify({ clientes: this.clientes, proximoId: this.proximoId }));
    } catch (e) { console.error('Erro ao salvar clientes:', e); }
  }

  listar(): Cliente[] { return [...this.clientes]; }

  adicionar(dados: ClienteFormData): Cliente {
    const novo: Cliente = { id: this.proximoId++, ...dados, dataCadastro: new Date().toISOString().split('T')[0] };
    this.clientes = [novo, ...this.clientes];
    this.salvarNoLocalStorage();
    return novo;
  }

  atualizar(id: number, dados: ClienteFormData): Cliente | null {
    const idx = this.clientes.findIndex(c => c.id === id);
    if (idx === -1) return null;
    const atualizado: Cliente = { id, ...dados, dataCadastro: this.clientes[idx].dataCadastro };
    this.clientes[idx] = atualizado;
    this.salvarNoLocalStorage();
    return atualizado;
  }

  excluir(id: number): void {
    this.clientes = this.clientes.filter(c => c.id !== id);
    this.salvarNoLocalStorage();
  }
}
