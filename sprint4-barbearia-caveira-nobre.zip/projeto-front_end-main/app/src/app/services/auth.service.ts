import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly SESSION_KEY = 'barbearia_sessao';

  login(usuario: string, senha: string): boolean {
    if (usuario === 'admin' && senha === '123456') {
      localStorage.setItem(this.SESSION_KEY, JSON.stringify({
        usuario,
        dataLogin: new Date().toISOString()
      }));
      return true;
    }
    return false;
  }

  logout(): void {
    localStorage.removeItem(this.SESSION_KEY);
  }

  estaLogado(): boolean {
    return localStorage.getItem(this.SESSION_KEY) !== null;
  }

  obterUsuario(): string | null {
    const dados = localStorage.getItem(this.SESSION_KEY);
    if (!dados) return null;
    return JSON.parse(dados).usuario;
  }
}
