export interface Profissional {
  id: number;
  nome: string;
  especialidade: string;
  telefone: string;
  ativo: boolean;
}

export type ProfissionalFormData = Omit<Profissional, 'id'>;
