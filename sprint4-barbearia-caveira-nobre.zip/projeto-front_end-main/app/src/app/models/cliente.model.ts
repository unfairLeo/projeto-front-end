export interface Cliente {
  id: number;
  nome: string;
  telefone: string;
  email: string;
  dataCadastro: string;
}

export type ClienteFormData = Omit<Cliente, 'id' | 'dataCadastro'>;
