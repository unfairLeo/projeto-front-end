import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent),
    canActivate: [authGuard]
  },
  {
    path: 'servicos',
    loadComponent: () => import('./pages/servicos/servicos.component').then(m => m.ServicosComponent),
    canActivate: [authGuard]
  },
  {
    path: 'registros',
    loadComponent: () => import('./pages/registros/registros.component').then(m => m.RegistrosComponent),
    canActivate: [authGuard]
  },
  {
    path: 'clientes',
    loadComponent: () => import('./pages/clientes/clientes.component').then(m => m.ClientesComponent),
    canActivate: [authGuard]
  },
  {
    path: 'profissionais',
    loadComponent: () => import('./pages/profissionais/profissionais.component').then(m => m.ProfissionaisComponent),
    canActivate: [authGuard]
  },
  {
    path: 'visagismo',
    loadComponent: () => import('./pages/visagismo/visagismo.component').then(m => m.VisagismoComponent),
    canActivate: [authGuard]
  },
  {
    path: 'sobre',
    loadComponent: () => import('./pages/sobre/sobre.component').then(m => m.SobreComponent),
    canActivate: [authGuard]
  },
  {
    path: 'agendamentos',
    redirectTo: 'registros'
  },
  {
    path: '**',
    redirectTo: 'login'
  }
];
