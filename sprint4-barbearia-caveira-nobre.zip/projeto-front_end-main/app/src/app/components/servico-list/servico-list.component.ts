import { CurrencyPipe } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Servico } from '../../models/servico.model';

@Component({
  selector: 'app-servico-list',
  imports: [CurrencyPipe],
  templateUrl: './servico-list.component.html',
  styleUrl: './servico-list.component.css'
})
export class ServicoListComponent {
  @Input() servicos: Servico[] = [];
  @Output() editar = new EventEmitter<Servico>();
  @Output() excluir = new EventEmitter<number>();
}
