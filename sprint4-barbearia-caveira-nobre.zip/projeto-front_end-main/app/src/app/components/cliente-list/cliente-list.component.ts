import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Cliente } from '../../models/cliente.model';

@Component({
  selector: 'app-cliente-list',
  templateUrl: './cliente-list.component.html',
  styleUrl: './cliente-list.component.css'
})
export class ClienteListComponent {
  @Input() clientes: Cliente[] = [];
  @Output() editar = new EventEmitter<Cliente>();
  @Output() excluir = new EventEmitter<number>();
}
