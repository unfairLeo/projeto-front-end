import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Cliente, ClienteFormData } from '../../models/cliente.model';

@Component({
  selector: 'app-cliente-form',
  imports: [FormsModule],
  templateUrl: './cliente-form.component.html',
  styleUrl: './cliente-form.component.css'
})
export class ClienteFormComponent implements OnChanges {
  @Input() clienteEdicao: Cliente | null = null;
  @Output() salvar = new EventEmitter<ClienteFormData>();
  @Output() cancelar = new EventEmitter<void>();

  form: ClienteFormData = this.vazio();
  erros: Partial<Record<keyof ClienteFormData, string>> = {};

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['clienteEdicao']) {
      if (this.clienteEdicao) {
        const { id: _id, dataCadastro: _d, ...dados } = this.clienteEdicao;
        this.form = { ...dados };
      } else {
        this.form = this.vazio();
      }
      this.erros = {};
    }
  }

  enviar(): void {
    this.erros = {};
    if (!this.form.nome.trim()) this.erros['nome'] = 'O nome é obrigatório.';
    if (!this.form.telefone.trim()) this.erros['telefone'] = 'O telefone é obrigatório.';
    if (this.form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.form.email)) {
      this.erros['email'] = 'Informe um e-mail válido.';
    }
    if (Object.keys(this.erros).length > 0) return;

    this.salvar.emit({ ...this.form, nome: this.form.nome.trim() });
    if (!this.clienteEdicao) this.form = this.vazio();
  }

  cancelarEdicao(): void {
    this.form = this.vazio();
    this.erros = {};
    this.cancelar.emit();
  }

  private vazio(): ClienteFormData {
    return { nome: '', telefone: '', email: '' };
  }
}
