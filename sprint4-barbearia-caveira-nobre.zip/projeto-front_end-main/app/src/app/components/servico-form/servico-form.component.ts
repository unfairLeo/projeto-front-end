import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Servico, ServicoFormData } from '../../models/servico.model';

@Component({
  selector: 'app-servico-form',
  imports: [FormsModule],
  templateUrl: './servico-form.component.html',
  styleUrl: './servico-form.component.css'
})
export class ServicoFormComponent implements OnChanges {
  @Input() servicoEdicao: Servico | null = null;

  @Output() salvar = new EventEmitter<ServicoFormData>();
  @Output() cancelar = new EventEmitter<void>();

  categorias: Servico['categoria'][] = ['Corte', 'Barba', 'Tratamento', 'Combo'];

  form: ServicoFormData = this.criarFormularioVazio();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['servicoEdicao']) {
      if (this.servicoEdicao) {
        const { id: _id, ...dadosFormulario } = this.servicoEdicao;
        this.form = { ...dadosFormulario };
      } else {
        this.form = this.criarFormularioVazio();
      }
    }
  }

  enviar(): void {
    if (!this.form.nome.trim() || !this.form.descricao.trim()) {
      alert('Preencha ao menos nome e descrição.');
      return;
    }

    this.salvar.emit({
      ...this.form,
      nome: this.form.nome.trim(),
      descricao: this.form.descricao.trim(),
      preco: Number(this.form.preco) || 0,
      popularidade: Number(this.form.popularidade) || 1
    });

    if (!this.servicoEdicao) {
      this.form = this.criarFormularioVazio();
    }
  }

  cancelarEdicao(): void {
    this.form = this.criarFormularioVazio();
    this.cancelar.emit();
  }

  private criarFormularioVazio(): ServicoFormData {
    return {
      nome: '',
      descricao: '',
      preco: 0,
      popularidade: 1,
      categoria: 'Corte'
    };
  }
}
