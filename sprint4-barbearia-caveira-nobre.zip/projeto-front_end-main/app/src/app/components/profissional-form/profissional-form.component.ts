import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Profissional, ProfissionalFormData } from '../../models/profissional.model';

@Component({
  selector: 'app-profissional-form',
  imports: [FormsModule],
  templateUrl: './profissional-form.component.html',
  styleUrl: './profissional-form.component.css'
})
export class ProfissionalFormComponent implements OnChanges {
  @Input() profissionalEdicao: Profissional | null = null;
  @Output() salvar = new EventEmitter<ProfissionalFormData>();
  @Output() cancelar = new EventEmitter<void>();

  especialidades = ['Corte', 'Barba', 'Tratamentos Capilares', 'Corte e Barba', 'Coloração', 'Visagismo'];
  form: ProfissionalFormData = this.vazio();
  erros: Partial<Record<keyof ProfissionalFormData, string>> = {};

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['profissionalEdicao']) {
      if (this.profissionalEdicao) {
        const { id: _id, ...dados } = this.profissionalEdicao;
        this.form = { ...dados };
      } else {
        this.form = this.vazio();
      }
      this.erros = {};
    }
  }

  enviar(): void {
    this.erros = {};
    if (!this.form.nome.trim()) this.erros['nome'] = 'O nome é obrigatório.';
    if (!this.form.especialidade.trim()) this.erros['especialidade'] = 'A especialidade é obrigatória.';
    if (Object.keys(this.erros).length > 0) return;
    this.salvar.emit({ ...this.form, nome: this.form.nome.trim() });
    if (!this.profissionalEdicao) this.form = this.vazio();
  }

  cancelarEdicao(): void {
    this.form = this.vazio();
    this.erros = {};
    this.cancelar.emit();
  }

  private vazio(): ProfissionalFormData {
    return { nome: '', especialidade: 'Corte e Barba', telefone: '', ativo: true };
  }
}
