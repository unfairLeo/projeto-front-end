import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Profissional } from '../../models/profissional.model';

@Component({
  selector: 'app-profissional-list',
  templateUrl: './profissional-list.component.html',
  styleUrl: './profissional-list.component.css'
})
export class ProfissionalListComponent {
  @Input() profissionais: Profissional[] = [];
  @Output() editar = new EventEmitter<Profissional>();
  @Output() excluir = new EventEmitter<number>();
}
