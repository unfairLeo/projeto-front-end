import { Component, Input, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-header',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  @Input({ required: true }) titulo = '';

  private authService = inject(AuthService);
  private router = inject(Router);

  get estaLogado(): boolean {
    return this.authService.estaLogado();
  }

  get usuario(): string | null {
    return this.authService.obterUsuario();
  }

  sair(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
