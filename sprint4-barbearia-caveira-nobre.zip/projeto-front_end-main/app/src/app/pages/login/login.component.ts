import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private authService = inject(AuthService);
  private router = inject(Router);

  usuario = '';
  senha = '';
  mensagemErro = '';
  carregando = false;

  entrar(): void {
    this.mensagemErro = '';

    if (!this.usuario.trim() || !this.senha.trim()) {
      this.mensagemErro = 'Informe usuário e senha.';
      return;
    }

    this.carregando = true;

    setTimeout(() => {
      const ok = this.authService.login(this.usuario.trim(), this.senha.trim());
      this.carregando = false;

      if (ok) {
        this.router.navigate(['/dashboard']);
      } else {
        this.mensagemErro = 'Usuário ou senha inválidos.';
      }
    }, 400);
  }
}
