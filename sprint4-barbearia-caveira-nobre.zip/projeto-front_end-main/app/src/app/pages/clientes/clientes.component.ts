import { Component, inject } from '@angular/core';
import { ClienteFormComponent } from '../../components/cliente-form/cliente-form.component';
import { ClienteListComponent } from '../../components/cliente-list/cliente-list.component';
import { Cliente, ClienteFormData } from '../../models/cliente.model';
import { ClientesService } from '../../services/clientes.service';

@Component({
  selector: 'app-clientes',
  imports: [ClienteFormComponent, ClienteListComponent],
  templateUrl: './clientes.component.html',
  styleUrl: './clientes.component.css'
})
export class ClientesComponent {
  private clientesService = inject(ClientesService);

  clientes: Cliente[] = [];
  clienteEdicao: Cliente | null = null;

  constructor() { this.atualizar(); }

  salvar(dados: ClienteFormData): void {
    if (this.clienteEdicao) {
      this.clientesService.atualizar(this.clienteEdicao.id, dados);
      this.clienteEdicao = null;
    } else {
      this.clientesService.adicionar(dados);
    }
    this.atualizar();
  }

  editar(c: Cliente): void {
    this.clienteEdicao = { ...c };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelar(): void { this.clienteEdicao = null; }

  excluir(id: number): void {
    if (!confirm('Deseja excluir este cliente?')) return;
    this.clientesService.excluir(id);
    this.atualizar();
  }

  private atualizar(): void { this.clientes = this.clientesService.listar(); }
}
