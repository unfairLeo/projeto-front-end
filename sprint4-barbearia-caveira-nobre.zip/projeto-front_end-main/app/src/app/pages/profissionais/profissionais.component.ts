import { Component, inject } from '@angular/core';
import { ProfissionalFormComponent } from '../../components/profissional-form/profissional-form.component';
import { ProfissionalListComponent } from '../../components/profissional-list/profissional-list.component';
import { Profissional, ProfissionalFormData } from '../../models/profissional.model';
import { ProfissionaisService } from '../../services/profissionais.service';

@Component({
  selector: 'app-profissionais',
  imports: [ProfissionalFormComponent, ProfissionalListComponent],
  templateUrl: './profissionais.component.html',
  styleUrl: './profissionais.component.css'
})
export class ProfissionaisComponent {
  private profissionaisService = inject(ProfissionaisService);

  profissionais: Profissional[] = [];
  profissionalEdicao: Profissional | null = null;

  constructor() { this.atualizar(); }

  salvar(dados: ProfissionalFormData): void {
    if (this.profissionalEdicao) {
      this.profissionaisService.atualizar(this.profissionalEdicao.id, dados);
      this.profissionalEdicao = null;
    } else {
      this.profissionaisService.adicionar(dados);
    }
    this.atualizar();
  }

  editar(p: Profissional): void {
    this.profissionalEdicao = { ...p };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelar(): void { this.profissionalEdicao = null; }

  excluir(id: number): void {
    if (!confirm('Deseja excluir este profissional?')) return;
    this.profissionaisService.excluir(id);
    this.atualizar();
  }

  private atualizar(): void { this.profissionais = this.profissionaisService.listar(); }
}
