import { Component, inject } from '@angular/core';
import { EmptyStateComponent } from '../../components/empty-state/empty-state.component';
import { ServicoFormComponent } from '../../components/servico-form/servico-form.component';
import { ServicoListComponent } from '../../components/servico-list/servico-list.component';
import { Servico, ServicoFormData } from '../../models/servico.model';
import { ServicosService } from '../../services/servicos.service';

@Component({
  selector: 'app-servicos',
  imports: [ServicoFormComponent, ServicoListComponent, EmptyStateComponent],
  templateUrl: './servicos.component.html',
  styleUrl: './servicos.component.css'
})
export class ServicosComponent {
  private servicosService = inject(ServicosService);

  servicos: Servico[] = [];
  servicoEdicao: Servico | null = null;

  constructor() {
    this.atualizarLista();
  }

  salvarServico(dados: ServicoFormData): void {
    if (this.servicoEdicao) {
      this.servicosService.atualizar(this.servicoEdicao.id, dados);
      this.servicoEdicao = null;
    } else {
      this.servicosService.adicionar(dados);
    }

    this.atualizarLista();
  }

  editarServico(servico: Servico): void {
    this.servicoEdicao = { ...servico };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelarEdicao(): void {
    this.servicoEdicao = null;
  }

  excluirServico(id: number): void {
    const confirmou = confirm('Deseja excluir este serviço?');

    if (!confirmou) {
      return;
    }

    this.servicosService.excluir(id);
    this.atualizarLista();
  }

  private atualizarLista(): void {
    this.servicos = this.servicosService.listar();
  }
}
