# Barbearia Caveira Nobre — Sprint 4

## Integrantes da Equipe
- (preencher com os nomes da equipe)

## Descrição Geral
Sistema de gestão para barbearia desenvolvido em Angular 21. Permite gerenciar agendamentos, serviços, clientes e profissionais com persistência via localStorage, autenticação simples e rotas protegidas por guard.

---

## Funcionalidades por Sprint

### Sprint 2
- Estrutura base do projeto Angular
- Componente de header com navegação
- Dashboard com cards de indicadores
- Page de Agendamentos (registros) com CRUD completo
- Filtro por texto, categoria e status

### Sprint 3
- CRUD de Serviços (servico-form, servico-list)
- Página de Visagismo com recomendações de corte por tipo de rosto e cabelo
- Footer adicionado
- Persistência em localStorage para Agendamentos e Serviços
- Correções de CSS e `@for` sem `track`

### Sprint 4
- **Login e Logout** com AuthService
- **Sessão persistida** no localStorage
- **AuthGuard** protegendo todas as rotas internas
- **CRUD de Clientes** (cliente-form, cliente-list, clientes page, cliente model, clientes service)
- **CRUD de Profissionais** (profissional-form, profissional-list, profissionais page, profissional model, profissionais service)
- **Animação suave** no ícone dos cards do dashboard
- **Menu atualizado** com todas as rotas e botão de logout
- README completo

---

## Credenciais de Acesso
| Campo   | Valor    |
|---------|----------|
| Usuário | `admin`  |
| Senha   | `123456` |

---

## Rotas da Aplicação
| Rota             | Página              | Protegida |
|------------------|---------------------|-----------|
| `/login`         | Tela de login       | Não       |
| `/dashboard`     | Painel de indicadores | Sim     |
| `/servicos`      | CRUD de serviços    | Sim       |
| `/registros`     | CRUD de agendamentos | Sim      |
| `/clientes`      | CRUD de clientes    | Sim       |
| `/profissionais` | CRUD de profissionais | Sim     |
| `/visagismo`     | Consulta de visagismo | Sim     |
| `/sobre`         | Sobre o projeto     | Sim       |

---

## Estrutura de Pastas
```
src/app/
├── components/
│   ├── header/            → cabeçalho + logout
│   ├── footer/            → rodapé
│   ├── dashboard-card/    → card reutilizável do dashboard
│   ├── item-form/         → formulário de agendamento
│   ├── item-list/         → lista de agendamentos
│   ├── servico-form/      → formulário de serviço
│   ├── servico-list/      → lista de serviços
│   ├── cliente-form/      → formulário de cliente
│   ├── cliente-list/      → lista de clientes
│   ├── profissional-form/ → formulário de profissional
│   ├── profissional-list/ → lista de profissionais
│   ├── filter-bar/        → barra de filtros
│   ├── empty-state/       → estado vazio
│   └── loading-error/     → estado de carregamento/erro
├── pages/
│   ├── login/             → tela de login
│   ├── dashboard/         → painel inicial
│   ├── registros/         → página de agendamentos
│   ├── servicos/          → página de serviços
│   ├── clientes/          → página de clientes
│   ├── profissionais/     → página de profissionais
│   ├── visagismo/         → consulta de visagismo
│   └── sobre/             → sobre o projeto
├── models/
│   ├── registro.model.ts
│   ├── servico.model.ts
│   ├── cliente.model.ts
│   └── profissional.model.ts
├── services/
│   ├── auth.service.ts
│   ├── registros.service.ts
│   ├── servicos.service.ts
│   ├── clientes.service.ts
│   ├── profissionais.service.ts
│   └── visagismo.service.ts
└── guards/
    └── auth.guard.ts
```

---

## Uso do localStorage
Cada service gerencia sua própria chave no localStorage:

| Service               | Chave                          |
|-----------------------|--------------------------------|
| AuthService           | `barbearia_sessao`             |
| RegistrosService      | `agendamentos_barbearia_dados` |
| ServicosService       | `barbearia_servicos`           |
| ClientesService       | `barbearia_clientes`           |
| ProfissionaisService  | `barbearia_profissionais`      |

Os componentes de interface **não acessam** o localStorage diretamente — apenas os services.

---

## Fluxo de Cadastro (exemplo: Cliente)
1. Usuário preenche o formulário em `ClienteFormComponent`
2. O componente emite `@Output() salvar` com os dados
3. `ClientesComponent` (page) recebe o evento e chama `clientesService.adicionar()`
4. `ClientesService` salva no localStorage e atualiza o array interno
5. A page recarrega a lista e passa por `@Input() clientes` para `ClienteListComponent`

---

## Como Executar
```bash
# Entrar na pasta do projeto
cd app

# Instalar dependências
npm install

# Executar a aplicação
ng serve

# Acessar no navegador
http://localhost:4200
```
